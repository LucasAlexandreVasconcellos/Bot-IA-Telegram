"""Testes da camada de qualidade. Execute: python -m unittest -v"""
import logging
import sqlite3
import tempfile
import unittest
from pathlib import Path

import criar_banco
import exemplo_integracao as integ
from qualidade_dados import (agregar_por_metrica, corrigir_texto, montar_contexto_ia,
                             tratar_lote, tratar_registro, validar_data, validar_numero)

logging.disable(logging.CRITICAL)


class TestTexto(unittest.TestCase):
    def test_mojibake_simples(self):
        self.assertEqual(corrigir_texto("OperaÃ§Ã£o")[0], "Operação")

    def test_mojibake_duas_camadas(self):
        texto = "Jurídico".encode().decode("latin-1").encode().decode("latin-1")
        self.assertEqual(corrigir_texto(texto)[0], "Jurídico")

    def test_texto_legitimo_com_til_nao_e_alterado(self):
        self.assertEqual(corrigir_texto("ÃREA")[0], "ÃREA")
        self.assertEqual(corrigir_texto("Operação")[0], "Operação")

    def test_latin1_em_bytes(self):
        texto, probs = corrigir_texto(b"Comunica\xe7\xe3o")
        self.assertEqual(texto, "Comunicação")
        self.assertIn("bytes_decodificados_cp1252", probs)

    def test_bytes_irrecuperaveis_sinalizados(self):
        _, probs = corrigir_texto(b"Finan\xe7eiro\x81")
        self.assertIn("bytes_utf8_invalidos", probs)

    def test_nulo_vazio_e_espacos(self):
        self.assertEqual(corrigir_texto(None), (None, ["texto_nulo"]))
        self.assertIsNone(corrigir_texto("")[0])
        self.assertIsNone(corrigir_texto("   ")[0])

    def test_controle_e_espacos(self):
        self.assertEqual(corrigir_texto("  Ven\x00das   Sul ")[0], "Vendas Sul")


class TestData(unittest.TestCase):
    def test_validas(self):
        self.assertEqual(validar_data("2026-01-01"), ("2026-01-01", []))

    def test_formatos_convertidos(self):
        for entrada in ("15/05/2026", "2026/05/15", "2026-05-15T10:30:00"):
            data, avisos = validar_data(entrada)
            self.assertEqual(data, "2026-05-15", entrada)
            self.assertIn("data_formato_convertido", avisos)

    def test_invalidas(self):
        for entrada in ("2026-15-45", "0000-00-00", "2026-02-30", "ontem", "31/02/2026"):
            self.assertIsNone(validar_data(entrada)[0], entrada)

    def test_ausentes_e_fora_do_intervalo(self):
        self.assertEqual(validar_data(None)[1], ["data_ausente"])
        self.assertEqual(validar_data("1850-01-01")[1], ["data_fora_do_intervalo"])


class TestNumero(unittest.TestCase):
    def test_validos(self):
        self.assertEqual(validar_numero(10)[0], 10.0)
        self.assertEqual(validar_numero("1234.5")[0], 1234.5)

    def test_formato_brasileiro(self):
        self.assertEqual(validar_numero("R$ 15.250,75")[0], 15250.75)
        self.assertEqual(validar_numero("1.234.567")[0], 1234567.0)
        self.assertEqual(validar_numero("1,234.56")[0], 1234.56)

    def test_rejeicoes(self):
        for entrada in ("muitos", "indefinida", "1,2,3", "1_000", True, float("inf"),
                        float("nan"), "nan", "inf"):
            self.assertIsNone(validar_numero(entrada)[0], entrada)
        self.assertEqual(validar_numero(None)[1], ["valor_ausente"])
        self.assertEqual(validar_numero("")[1], ["valor_ausente"])


class TestRegistro(unittest.TestCase):
    base = dict(id=1, departamento="Vendas", metrica="Faturamento",
                tipo_periodo="mensal", periodo="2026-01-01",
                valor_monetario=100.0, variacao=1.0)

    def tratar(self, **mudancas):
        return tratar_registro({**self.base, **mudancas})

    def test_registro_limpo(self):
        r = self.tratar()
        self.assertTrue(r["utilizavel"])
        self.assertEqual(r["problemas_qualidade"], [])

    def test_nao_altera_original(self):
        original = dict(self.base, departamento="OperaÃ§Ã£o")
        copia = dict(original)
        tratar_registro(original)
        self.assertEqual(original, copia)

    def test_negativo_anomalo_vs_estorno(self):
        self.assertFalse(self.tratar(valor_monetario=-5.0)["utilizavel"])
        self.assertTrue(self.tratar(metrica="Estorno", valor_monetario=-5.0)["utilizavel"])

    def test_valor_absurdo(self):
        self.assertFalse(self.tratar(valor_monetario=9.9e15)["utilizavel"])

    def test_variacao_invalida_nao_bloqueia_e_vira_none(self):
        r = self.tratar(variacao="indefinida")
        self.assertTrue(r["utilizavel"])
        self.assertIsNone(r["variacao"])

    def test_campos_obrigatorios(self):
        for campo in ("departamento", "metrica", "tipo_periodo", "periodo"):
            self.assertFalse(self.tratar(**{campo: None})["utilizavel"], campo)

    def test_tipo_periodo_normalizado(self):
        self.assertEqual(self.tratar(tipo_periodo="Mensal ")["tipo_periodo"], "mensal")


class TestLote(unittest.TestCase):
    def test_linha_corrompida_nao_derruba_lote(self):
        lote = tratar_lote([{"id": 1}, None, "texto", 42])
        self.assertEqual(lote["total"], 4)
        self.assertEqual(lote["total_validos"], 0)

    def test_lote_vazio(self):
        self.assertEqual(tratar_lote([])["total"], 0)
        self.assertIn("Não há registros válidos", montar_contexto_ia(tratar_lote([])))


class TestIntegracaoComBanco(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db = Path(cls.tmp.name) / "teste.db"
        criar_banco.criar_banco(cls.db)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_consulta_padrao_do_sqlite_quebra_com_text_invalido(self):
        """Documenta POR QUE o text_factory=bytes é obrigatório."""
        con = sqlite3.connect(self.db)
        with self.assertRaises(sqlite3.OperationalError):
            con.execute("SELECT * FROM indicadores_empresa").fetchall()
        con.close()

    def test_consulta_defensiva_nao_quebra(self):
        r = integ.consultar_indicadores(self.db)
        self.assertEqual(r["total"], 27)
        self.assertEqual(r["total_validos"], 13)
        self.assertEqual(r["falhas_processamento"], [])

    def test_ids_esperados_isolados(self):
        r = integ.consultar_indicadores(self.db)
        invalidos = {x["id"] for x in r["invalidos"]}
        self.assertEqual(invalidos, {6, 7, 8, 9, 10, 11, 12, 13, 18, 19, 21, 22, 25, 26})

    def test_nenhum_valido_tem_lixo(self):
        for x in integ.consultar_indicadores(self.db)["validos"]:
            self.assertGreaterEqual(x["valor_monetario"] >= 0 or x["metrica"] == "Estorno", True)
            for campo in ("departamento", "metrica"):
                self.assertNotIn("\ufffd", x[campo])
                self.assertNotIn("Ã", x[campo])
            self.assertRegex(x["periodo"], r"^\d{4}-\d{2}-\d{2}$")

    def test_totais_nao_misturam_metricas(self):
        totais = agregar_por_metrica(integ.consultar_indicadores(self.db)["validos"])
        self.assertEqual(totais[("Vendas", "Faturamento")], 715500.0)
        self.assertEqual(totais[("Financeiro", "Receita")], 110250.75)

    def test_contexto_ia_nao_vaza_dados_ruins(self):
        ctx = integ.contexto_para_ia(self.db)
        for lixo in ("999999", "indefinida", "muitos", "\ufffd", "Ã", "0000-00-00"):
            self.assertNotIn(lixo, ctx)

    def test_banco_inexistente_ou_sem_tabela_responde_com_mensagem(self):
        vazio = Path(self.tmp.name) / "vazio.db"
        sqlite3.connect(vazio).close()
        self.assertIn("Não consegui acessar", integ.responder_consulta(vazio))
        self.assertIn("indisponíveis", integ.contexto_para_ia(vazio))


if __name__ == "__main__":
    unittest.main(verbosity=2)
