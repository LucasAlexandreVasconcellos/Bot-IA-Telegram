# Integrante 2 — Tratamento de Casos de Borda e Qualidade de Dados

## 1. Objetivo

Dar resiliência ao Jarvis: identificar, normalizar e isolar dados inconsistentes **antes** de
chegarem a cálculos, gráficos ou à IA, de forma que nenhuma linha corrompida derrube o sistema
nem faça a IA responder com números inventados.

## 2. Arquivos

| Arquivo | Função |
|---|---|
| `criar_banco.py` | Cria a tabela e popula 27 registros: dados limpos + casos de borda intencionais. |
| `qualidade_dados.py` | Validações e normalizações (texto, data, número, registro, lote) e geração do contexto seguro para a IA. |
| `exemplo_integracao.py` | Consulta SQLite defensiva, resposta ao usuário e contexto para a OpenAI. Base para a função `consultar_banco()` do `bot.py`. |
| `test_qualidade_dados.py` | 30 testes automatizados (apenas `unittest`). |
| `sandbox_jarvis.db` | Gerado ao executar `criar_banco.py`. |

## 3. Como executar

Requer Python 3.10+. Sem dependências externas.

```bash
python criar_banco.py          # recria o banco (apaga indicadores_empresa!)
python exemplo_integracao.py   # mostra resposta e contexto enviado à IA
python -m unittest -v          # roda os testes
```

> `criar_banco.py` apaga e recria a tabela `indicadores_empresa`. Use só em banco de teste.

## 4. Cenários de erro e comportamento do sistema

Resultado real da execução sobre a base de demonstração (**13 registros válidos, 14 isolados**).

| ID | Cenário | Dado no banco | Comportamento | Utilizável |
|---|---|---|---|---|
| 5 | Mojibake (UTF-8 lido como Latin-1) | `OperaÃ§Ã£o` | Corrigido para `Operação`; sinaliza `codificacao_corrigida` | ✅ |
| 15 | Mojibake em duas camadas | `JurÃÂ­dico` | Corrigido para `Jurídico` | ✅ |
| 14 | Latin-1 real (BLOB) | `Comunica\xe7\xe3o` | Decodificado via cp1252 → `Comunicação`; sinaliza `bytes_decodificados_cp1252` | ✅ |
| 27 | **TEXT** com bytes inválidos em UTF-8 | `Produ\xe7\xe3o` | Sem tratamento, o SQLite lança `OperationalError` e a **consulta inteira falha**. Com `text_factory=bytes` a linha é lida e recuperada como `Produção` | ✅ |
| 12 | Bytes irrecuperáveis | `Finan\xe7eiro\x81` | Sobra `U+FFFD`; um rótulo corrompido não pode ser chave de agrupamento → isolado | ❌ |
| 6 | Valor negativo anômalo | `-999999.00` em Faturamento | Sinaliza `negativo_anomalo`; fora dos cálculos | ❌ |
| 23 | Negativo legítimo | `-3500.00` em *Estorno* | Aceito (métrica na lista `METRICAS_COM_NEGATIVO_PERMITIDO`) | ✅ |
| 7 | Data impossível | `2026-15-45` | `data_invalida`; período nulo; isolado | ❌ |
| 18 | Data "zero" do MySQL | `0000-00-00` | `data_invalida`; isolado | ❌ |
| 19 | Data em texto livre | `ontem` | `data_formato_invalido`; isolado | ❌ |
| 16 | Data no padrão brasileiro | `15/05/2026` | Convertida para `2026-05-15` (assume DD/MM/AAAA); sinaliza conversão | ✅ |
| 17 | Data ISO com hora | `2026-06-01T00:00:00` | Convertida para `2026-06-01` | ✅ |
| 8, 9 | Campo nulo | `departamento`/`metrica` = NULL | `campos_obrigatorios_ausentes`; isolado | ❌ |
| 10, 25 | Campo vazio ou só espaços | `''`, `'   '` | Normalizado como ausente; isolado | ❌ |
| 24 | Espaços/caixa fora do padrão | `'  Vendas  '`, `'Mensal '` | `Vendas`, `mensal`; agrega junto aos demais | ✅ |
| 11 | Valor ausente + variação inválida | `NULL` / `'indefinida'` | Sem valor monetário → isolado | ❌ |
| 13 | Texto em coluna numérica | `'muitos'` | `valor_nao_numerico`; isolado | ❌ |
| 20 | Valor em formato brasileiro | `'R$ 15.250,75'` | Convertido para `15250.75`; sinaliza conversão | ✅ |
| 21 | Infinito | `inf` | `valor_nao_finito`; isolado | ❌ |
| 22 | Valor absurdo (erro de escala) | `9.9e15` | Acima de `VALOR_MAXIMO_PLAUSIVEL` (1e12); isolado | ❌ |
| 26 | Registro duplicado | Cópia do id 1 | Mantém o primeiro, isola o duplicado (`registro_duplicado:id_original=1`) | ❌ |
| — | Variação inválida (isolada) | `'indefinida'` | **Nunca bloqueia** o registro; vira `None`, e o texto não chega à IA | ✅ |
| — | Linha que gera exceção inesperada | qualquer | Capturada em `tratar_lote`; contada em `falhas_processamento`; o lote continua | — |
| — | Banco inacessível / sem tabela | — | `responder_consulta()` devolve mensagem amigável; `contexto_para_ia()` instrui a IA a **não inventar valores** | — |

## 5. Regras de qualidade

1. O dado original **não** é alterado; o tratamento devolve uma cópia com `problemas_qualidade` e `utilizavel`.
2. Leitura com `text_factory=bytes`: a decodificação é feita linha a linha por `corrigir_texto()`. Ordem: UTF-8 → cp1252 → substituição (esta é isolada).
3. Mojibake é corrigido em até 2 camadas, apenas quando há marcadores típicos. Textos legítimos como `ÃREA` não são alterados.
4. Datas devem existir no calendário e estar entre 2000 e 2100. Formatos conhecidos são convertidos para ISO e sinalizados.
5. Números aceitam `1234.56`, `1.234,56`, `1,234.56` e `R$ …`. Rejeitam NaN, infinito, booleanos e texto. **Ambiguidade assumida:** `"1,234"` é lido como 1,234 (vírgula decimal, padrão brasileiro).
6. Negativos são anomalia, exceto em métricas de estorno/ajuste/devolução/reembolso/desconto (configurável).
7. `departamento`, `metrica`, `tipo_periodo` e `periodo` são obrigatórios.
8. Totais são calculados **por departamento e métrica**, sem somar métricas diferentes.
9. Todos os parâmetros (limites, métricas, tipos de período) ficam no topo de `qualidade_dados.py`.

## 6. Integração com o bot e a IA

```python
from exemplo_integracao import contexto_para_ia, responder_consulta

contexto = contexto_para_ia()      # só registros validados + contagem de isolados
# anexar `contexto` ao prompt/system message enviado à OpenAI
```

- A validação roda **antes** da montagem do prompt e da geração de gráficos.
- A IA recebe apenas registros válidos e a quantidade de isolados, **sem** o conteúdo dos erros, com a instrução de não estimar nem inferir valores ausentes.
- A lista enviada é limitada a 200 linhas (`LIMITE_LINHAS_CONTEXTO_IA`).
- Se não houver nenhum registro válido, ou se o banco falhar, o contexto instrui a IA a informar indisponibilidade em vez de inventar.
- Mantenha também `try/except` no handler do Telegram.

## 7. Logs

Logger `jarvis.qualidade`: registra apenas `id` e **códigos** de problema (nunca o conteúdo dos dados). Em produção, configure um handler de arquivo ou o sistema central de logs.

## 8. Limitações conhecidas

- A lista de métricas com negativo permitido é um palpite para esta base; ajuste conforme o negócio.
- Mojibake e Latin-1 são tentativas heurísticas; o que não for recuperável é isolado, não "adivinhado".
- Datas ambíguas como `03/04/2026` são interpretadas como DD/MM/AAAA.
- A deduplicação considera (departamento, métrica, tipo de período, período); duas medições legítimas diferentes com a mesma chave seriam tratadas como duplicata.
- Não há persistência dos problemas detectados. Evolução recomendada: tabela de ocorrências (`id_registro`, `campo`, `problema`, `data_deteccao`, `acao`).
