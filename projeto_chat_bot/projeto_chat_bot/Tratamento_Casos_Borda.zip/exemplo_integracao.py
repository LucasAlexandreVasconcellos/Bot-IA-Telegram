"""
Exemplo de integração da camada de qualidade com consultas SQLite.
Adapte para a função consultar_banco() do bot.py.
"""
import logging
import sqlite3
from pathlib import Path

from qualidade_dados import (agregar_por_metrica, formatar_brl,
                             montar_contexto_ia, tratar_lote)

logging.basicConfig(level=logging.INFO)
CAMINHO_BANCO = Path(__file__).with_name("sandbox_jarvis.db")


def consultar_indicadores(caminho=CAMINHO_BANCO):
    """Lê a tabela inteira e devolve o resultado de tratar_lote()."""
    conexao = sqlite3.connect(caminho)
    # ESSENCIAL: com o padrão (str), uma única célula TEXT com bytes que não são
    # UTF-8 faz o SQLite lançar OperationalError e derruba a consulta inteira.
    # Com `bytes`, a decodificação passa a ser feita por corrigir_texto(), linha a linha.
    conexao.text_factory = bytes
    conexao.row_factory = sqlite3.Row
    try:
        linhas = conexao.execute("""
            SELECT id, departamento, metrica, tipo_periodo,
                   periodo, valor_monetario, variacao
            FROM indicadores_empresa
            ORDER BY id
        """).fetchall()
        return tratar_lote([dict(linha) for linha in linhas])
    finally:
        conexao.close()


def responder_consulta(caminho=CAMINHO_BANCO):
    """Resposta amigável; nenhuma falha de dados chega ao usuário como traceback."""
    try:
        resultado = consultar_indicadores(caminho)
        if not resultado["validos"]:
            return "Não encontrei dados válidos para responder. Verifique a qualidade da base."

        linhas = [f"Encontrei {resultado['total_validos']} registros válidos de "
                  f"{resultado['total']}; {resultado['total_invalidos']} foram isolados por inconsistência.",
                  "Totais por departamento/métrica:"]
        for (depto, metrica), total in sorted(agregar_por_metrica(resultado["validos"]).items()):
            linhas.append(f"- {depto} / {metrica}: {formatar_brl(total)}")
        return "\n".join(linhas)

    except sqlite3.Error:
        logging.exception("Erro ao consultar o banco")
        return "Não consegui acessar os dados agora. Tente novamente em instantes."
    except Exception:
        logging.exception("Erro inesperado durante a consulta")
        return "Ocorreu um problema ao processar os dados. A consulta não foi concluída."


def contexto_para_ia(caminho=CAMINHO_BANCO):
    """
    Texto a ser anexado ao prompt da OpenAI. Só contém registros validados.
    Se o banco falhar, devolve uma instrução segura em vez de levantar exceção.
    """
    try:
        return montar_contexto_ia(consultar_indicadores(caminho))
    except Exception:
        logging.exception("Falha ao montar contexto para a IA")
        return ("Os dados estão temporariamente indisponíveis. Informe isso ao "
                "usuário e NÃO invente valores.")


if __name__ == "__main__":
    print(responder_consulta())
    print("\n--- Contexto enviado à IA ---")
    print(contexto_para_ia())
