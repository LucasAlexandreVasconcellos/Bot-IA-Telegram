"""
Cria e popula o banco de demonstração do Jarvis.
Inclui intencionalmente dados limpos e casos de borda para testes.
ATENÇÃO: este script apaga e recria a tabela indicadores_empresa.
"""
import sqlite3
from pathlib import Path

CAMINHO_BANCO = Path(__file__).with_name("sandbox_jarvis.db")

# 'Jurídico' com DUAS camadas de mojibake ('JurÃÂ­dico')
_JURIDICO_DUPLO = "Jurídico".encode("utf-8").decode("latin-1").encode("utf-8").decode("latin-1")


def criar_banco(caminho=CAMINHO_BANCO):
    conexao = sqlite3.connect(caminho)
    cursor = conexao.cursor()

    cursor.execute("DROP TABLE IF EXISTS indicadores_empresa")
    cursor.execute("""
        CREATE TABLE indicadores_empresa (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            departamento TEXT,
            metrica TEXT,
            tipo_periodo TEXT,
            periodo TEXT,
            valor_monetario REAL,
            variacao REAL
        )
    """)

    registros = [
        # ---- Registros normais (ids 1-4)
        ("Vendas", "Faturamento", "mensal", "2026-01-01", 125000.00, 8.5),
        ("Vendas", "Faturamento", "mensal", "2026-02-01", 138500.00, 10.8),
        ("Marketing", "Investimento", "mensal", "2026-01-01", 18000.00, 4.2),
        ("Financeiro", "Receita", "mensal", "2026-02-01", 95000.00, 5.0),

        # ---- Caso 1 (id 5): mojibake UTF-8 lido como Latin-1
        ("OperaÃ§Ã£o", "Faturamento", "mensal", "2026-03-01", 87000.00, 3.1),
        # ---- Caso 2 (id 6): valor monetário negativo anômalo
        ("Vendas", "Faturamento", "mensal", "2026-04-01", -999999.00, -150.0),
        # ---- Caso 3 (id 7): data impossível
        ("Marketing", "Investimento", "mensal", "2026-15-45", 22000.00, 2.0),
        # ---- Caso 4 (ids 8-9): campos nulos
        (None, "Receita", "mensal", "2026-05-01", 70000.00, 1.5),
        ("RH", None, "mensal", "2026-05-01", 12000.00, 0.5),
        # ---- Caso 5 (id 10): campo vazio
        ("", "Custos", "mensal", "2026-06-01", 45000.00, 2.5),
        # ---- Caso 6 (id 11): valor ausente e variação não numérica
        ("Logística", "Custos", "mensal", "2026-06-01", None, "indefinida"),
        # ---- Caso 7 (id 12): BLOB irrecuperável (\x81 não existe em UTF-8 nem em cp1252)
        (sqlite3.Binary(b"Finan\xe7eiro\x81"), "Receita", "mensal", "2026-07-01", 56000.00, 1.2),
        # ---- Caso 8 (id 13): texto em coluna REAL
        ("TI", "Despesas", "mensal", "2026-08-01", "muitos", 2.0),

        # ---- Casos adicionais (ids 14-26)
        # 9: Latin-1 real gravado como BLOB ('Comunicação')
        (sqlite3.Binary(b"Comunica\xe7\xe3o"), "Investimento", "mensal", "2026-03-01", 30000.00, 1.0),
        # 10: mojibake em duas camadas
        (_JURIDICO_DUPLO, "Custos", "mensal", "2026-03-01", 21000.00, 0.8),
        # 11: datas fora do padrão ISO
        ("Vendas", "Faturamento", "mensal", "15/05/2026", 142000.00, 2.5),
        ("Vendas", "Faturamento", "mensal", "2026-06-01T00:00:00", 150000.00, 5.6),
        # 12: datas inválidas (zero-date do MySQL e texto livre)
        ("Marketing", "Investimento", "mensal", "0000-00-00", 15000.00, 1.0),
        ("Marketing", "Investimento", "mensal", "ontem", 16000.00, 1.0),
        # 13: valor monetário como texto em formato brasileiro
        ("Financeiro", "Receita", "mensal", "2026-03-01", "R$ 15.250,75", 2.2),
        # 14: valor infinito e valor absurdo (erro de escala)
        ("Vendas", "Faturamento", "mensal", "2026-09-01", float("inf"), 1.0),
        ("Vendas", "Faturamento", "mensal", "2026-10-01", 9.9e15, 1.0),
        # 15: negativo LEGÍTIMO (estorno) - deve ser aceito
        ("Financeiro", "Estorno", "mensal", "2026-03-01", -3500.00, -1.0),
        # 16: espaços sobrando / só espaços / caixa diferente
        ("  Vendas  ", "Faturamento", "Mensal ", "2026-07-01", 160000.00, 6.0),
        ("   ", "Custos", "mensal", "2026-07-01", 5000.00, 0.1),
        # 17: duplicata exata de um registro existente
        ("Vendas", "Faturamento", "mensal", "2026-01-01", 125000.00, 8.5),
    ]

    cursor.executemany("""
        INSERT INTO indicadores_empresa
        (departamento, metrica, tipo_periodo, periodo, valor_monetario, variacao)
        VALUES (?, ?, ?, ?, ?, ?)
    """, registros)

    # Caso 18 (id 27): coluna TEXT com bytes que NÃO são UTF-8 válido.
    # É o caso mais perigoso: com o text_factory padrão, o SQLite lança
    # OperationalError ("Could not decode to UTF-8") e a consulta inteira falha.
    cursor.execute("""
        INSERT INTO indicadores_empresa
        (departamento, metrica, tipo_periodo, periodo, valor_monetario, variacao)
        VALUES (CAST(? AS TEXT), 'Receita', 'mensal', '2026-04-01', 48000.00, 1.1)
    """, (sqlite3.Binary(b"Produ\xe7\xe3o"),))

    conexao.commit()
    conexao.close()
    print(f"Banco criado e populado em: {caminho}")


if __name__ == "__main__":
    criar_banco()
