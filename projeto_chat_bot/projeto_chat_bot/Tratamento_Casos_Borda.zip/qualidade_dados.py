"""
Camada defensiva de qualidade de dados do Jarvis.

Python 3.10+ | SQLite | sem dependências externas.

Princípios:
  * Nunca alterar o dado original no banco: o tratamento devolve uma CÓPIA.
  * Nunca levantar exceção por causa de uma linha ruim: o problema é registrado
    e o registro é isolado (utilizavel=False) ou corrigido e sinalizado.
  * Só registros aprovados chegam a cálculos, gráficos e ao contexto da IA.
"""
from __future__ import annotations

import logging
import math
import re
import unicodedata
from collections.abc import Mapping
from datetime import date, datetime
from typing import Any

logger = logging.getLogger("jarvis.qualidade")

# --------------------------------------------------------------------------
# Configuração das regras (ajuste conforme o significado dos indicadores)
# --------------------------------------------------------------------------
# Métricas em que valor negativo é legítimo (estornos, ajustes etc.).
METRICAS_COM_NEGATIVO_PERMITIDO = {
    "estorno", "ajuste", "devolução", "devolucao", "reembolso", "desconto",
}
TIPOS_PERIODO_VALIDOS = {"diario", "diário", "semanal", "mensal", "trimestral",
                         "semestral", "anual"}
ANO_MINIMO, ANO_MAXIMO = 2000, 2100
VALOR_MAXIMO_PLAUSIVEL = 1e12   # acima disso é tratado como erro de escala/digitação
CAMPOS_OBRIGATORIOS = ("departamento", "metrica", "tipo_periodo", "periodo")
LIMITE_LINHAS_CONTEXTO_IA = 200  # evita estourar o prompt enviado à IA

_MARCADORES_MOJIBAKE = ("Ã", "Â", "â€", "ï»¿")
_CONTROLE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


# --------------------------------------------------------------------------
# Texto
# --------------------------------------------------------------------------
def corrigir_texto(valor: Any) -> tuple[str | None, list[str]]:
    """Normaliza texto, corrige mojibake/Latin-1 e trata bytes inválidos."""
    problemas: list[str] = []

    if valor is None:
        return None, ["texto_nulo"]

    if isinstance(valor, (bytes, bytearray, memoryview)):
        bruto = bytes(valor)
        try:
            texto = bruto.decode("utf-8")
        except UnicodeDecodeError:
            # Muito comum: dado gravado em Latin-1/Windows-1252.
            try:
                texto = bruto.decode("cp1252")
                problemas.append("bytes_decodificados_cp1252")
            except UnicodeDecodeError:
                texto = bruto.decode("utf-8", errors="replace")
                problemas.append("bytes_utf8_invalidos")
    else:
        texto = str(valor)

    # 'OperaÃ§Ã£o' -> 'Operação' (até 2 camadas de mojibake).
    for _ in range(2):
        if not any(m in texto for m in _MARCADORES_MOJIBAKE):
            break
        corrigido = None
        for codec in ("latin-1", "cp1252"):
            try:
                corrigido = texto.encode(codec).decode("utf-8")
                break
            except (UnicodeEncodeError, UnicodeDecodeError):
                continue
        if corrigido is None or corrigido == texto:
            break
        texto = corrigido
        if "codificacao_corrigida" not in problemas:
            problemas.append("codificacao_corrigida")

    texto = texto.lstrip("\ufeff")  # BOM
    if _CONTROLE.search(texto):
        texto = _CONTROLE.sub("", texto)
        problemas.append("caracteres_controle_removidos")
    texto = re.sub(r"\s+", " ", unicodedata.normalize("NFC", texto)).strip()

    if "\ufffd" in texto:
        problemas.append("caracteres_substituicao_presentes")
    if not texto:
        return None, problemas + ["texto_vazio"]
    return texto, problemas


# --------------------------------------------------------------------------
# Datas
# --------------------------------------------------------------------------
_RE_ISO = re.compile(r"(\d{4})-(\d{2})-(\d{2})")
_RE_ISO_HORA = re.compile(r"(\d{4})-(\d{2})-(\d{2})[T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?")
_RE_BR = re.compile(r"(\d{2})[/.-](\d{2})[/.-](\d{4})")      # DD/MM/AAAA
_RE_AAAA_BARRA = re.compile(r"(\d{4})/(\d{2})/(\d{2})")      # AAAA/MM/DD


def validar_data(valor: Any) -> tuple[str | None, list[str]]:
    """
    Devolve a data no padrão ISO (YYYY-MM-DD).
    Converte formatos comuns (DD/MM/AAAA, AAAA/MM/DD, ISO com hora) e sinaliza.
    Rejeita datas impossíveis ('2026-15-45', '0000-00-00') e fora do intervalo.
    """
    if isinstance(valor, datetime):
        valor = valor.date()
    if isinstance(valor, date):
        valor = valor.isoformat()

    if valor is None or str(valor).strip() == "":
        return None, ["data_ausente"]

    texto = str(valor).strip()
    avisos: list[str] = []

    if _RE_ISO.fullmatch(texto):
        ano, mes, dia = map(int, texto.split("-"))
    elif (m := _RE_ISO_HORA.fullmatch(texto)):
        ano, mes, dia = int(m[1]), int(m[2]), int(m[3])
        avisos.append("data_formato_convertido")
    elif (m := _RE_BR.fullmatch(texto)):
        dia, mes, ano = int(m[1]), int(m[2]), int(m[3])   # padrão brasileiro
        avisos.append("data_formato_convertido")
    elif (m := _RE_AAAA_BARRA.fullmatch(texto)):
        ano, mes, dia = int(m[1]), int(m[2]), int(m[3])
        avisos.append("data_formato_convertido")
    else:
        return None, ["data_formato_invalido"]

    try:
        data = date(ano, mes, dia)
    except ValueError:
        return None, ["data_invalida"]

    if not (ANO_MINIMO <= data.year <= ANO_MAXIMO):
        return None, ["data_fora_do_intervalo"]
    return data.isoformat(), avisos


# --------------------------------------------------------------------------
# Números
# --------------------------------------------------------------------------
def _numero_de_texto(texto: str) -> tuple[float | None, bool]:
    """Converte '1.234,56', 'R$ 15.250,75', '1,234.56'. Retorna (número, foi_convertido)."""
    s = re.sub(r"^(R\$|\$)\s*", "", texto.strip(), flags=re.IGNORECASE)
    s = re.sub(r"[\s\u00a0]", "", s)
    if not s or "_" in s:
        return None, False
    try:                       # formato "limpo": 1234.56, 1e5, inf, nan
        return float(s), False
    except ValueError:
        pass

    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):      # 1.234,56 (BR)
            s = s.replace(".", "").replace(",", ".")
        else:                                # 1,234.56 (US)
            s = s.replace(",", "")
    elif "," in s:
        if s.count(",") != 1:
            return None, False
        s = s.replace(",", ".")              # 1234,56 (vírgula decimal)
    elif s.count(".") > 1:
        if not re.fullmatch(r"[+-]?\d{1,3}(\.\d{3})+", s):
            return None, False
        s = s.replace(".", "")               # 1.234.567

    if not re.fullmatch(r"[+-]?\d+(\.\d+)?", s):
        return None, False
    return float(s), True


def validar_numero(valor: Any) -> tuple[float | None, list[str]]:
    """Converte para float; rejeita nulo, bool, texto, NaN e infinito."""
    if valor is None or (isinstance(valor, (str, bytes)) and not valor.strip()):
        return None, ["valor_ausente"]
    if isinstance(valor, bool):
        return None, ["valor_nao_numerico"]

    avisos: list[str] = []
    if isinstance(valor, (int, float)):
        numero = float(valor)
    else:
        if isinstance(valor, (bytes, bytearray)):
            valor = bytes(valor).decode("utf-8", errors="replace")
        numero, convertido = _numero_de_texto(str(valor))
        if numero is None:
            return None, ["valor_nao_numerico"]
        if convertido:
            avisos.append("valor_formato_convertido")

    if not math.isfinite(numero):
        return None, ["valor_nao_finito"]
    return numero, avisos


# --------------------------------------------------------------------------
# Registro e lote
# --------------------------------------------------------------------------
def tratar_registro(registro: Mapping[str, Any]) -> dict[str, Any]:
    """
    Valida um registro de indicadores_empresa. Não altera a linha original:
    devolve uma cópia normalizada com `problemas_qualidade` e `utilizavel`.
    """
    resultado = dict(registro)
    problemas: list[str] = []

    for campo in ("departamento", "metrica", "tipo_periodo"):
        texto, erros = corrigir_texto(resultado.get(campo))
        resultado[campo] = texto
        problemas.extend(f"{campo}:{e}" for e in erros)

    if resultado["tipo_periodo"]:
        resultado["tipo_periodo"] = resultado["tipo_periodo"].lower()
        if resultado["tipo_periodo"] not in TIPOS_PERIODO_VALIDOS:
            problemas.append("tipo_periodo:valor_desconhecido")

    # Período: texto -> data ISO. Datas impossíveis ficam fora de análises temporais.
    periodo_bruto = resultado.get("periodo")
    if isinstance(periodo_bruto, (bytes, bytearray)):
        periodo_bruto, _ = corrigir_texto(periodo_bruto)
    periodo, erros = validar_data(periodo_bruto)
    resultado["periodo"] = periodo
    problemas.extend(f"periodo:{e}" for e in erros)

    valor, erros = validar_numero(resultado.get("valor_monetario"))
    resultado["valor_monetario"] = valor
    problemas.extend(f"valor_monetario:{e}" for e in erros)

    # A variação nunca bloqueia o registro, mas um valor inválido vira None
    # para que o texto "indefinida" jamais chegue à IA como se fosse número.
    variacao, erros = validar_numero(resultado.get("variacao"))
    resultado["variacao"] = variacao
    problemas.extend(f"variacao:{e}" for e in erros)

    bloqueios: list[str] = []
    # Texto com U+FFFD não é recuperável: usaria um rótulo corrompido como chave.
    if any("caracteres_substituicao_presentes" in p or "bytes_utf8_invalidos" in p
           for p in problemas):
        bloqueios.append("texto_irrecuperavel")
    if valor is not None:
        if abs(valor) > VALOR_MAXIMO_PLAUSIVEL:
            problemas.append("valor_monetario:fora_do_intervalo_plausivel")
            bloqueios.append("valor_fora_do_intervalo")
        elif valor < 0:
            metrica = (resultado["metrica"] or "").casefold()
            if metrica in METRICAS_COM_NEGATIVO_PERMITIDO:
                problemas.append("valor_monetario:negativo_permitido_pela_metrica")
            else:
                problemas.append("valor_monetario:negativo_anomalo")
                bloqueios.append("valor_negativo")

    faltantes = [c for c in CAMPOS_OBRIGATORIOS if not resultado.get(c)]
    if faltantes:
        problemas.append("campos_obrigatorios_ausentes:" + ",".join(faltantes))

    resultado["problemas_qualidade"] = problemas
    resultado["utilizavel"] = (
        not faltantes and not bloqueios and valor is not None
    )

    if problemas:
        # Registra apenas id e códigos de problema (sem o conteúdo dos dados).
        logger.warning("Qualidade: id=%s problemas=%s",
                       resultado.get("id"), ", ".join(problemas))
    return resultado


def tratar_lote(registros: list[Mapping[str, Any]]) -> dict[str, Any]:
    """Processa vários registros sem que uma linha ruim interrompa o lote."""
    tratados: list[dict[str, Any]] = []
    falhas: list[dict[str, Any]] = []

    for indice, registro in enumerate(registros):
        try:
            tratados.append(tratar_registro(registro))
        except Exception:  # defesa final: nenhuma linha derruba o sistema
            logger.exception("Falha inesperada ao tratar registro na posição %s", indice)
            falhas.append({"indice": indice})

    # Duplicados: mantém o primeiro e isola os demais.
    vistos: dict[tuple, Any] = {}
    for r in tratados:
        if not r["utilizavel"]:
            continue
        chave = (r["departamento"].casefold(), r["metrica"].casefold(),
                 r["tipo_periodo"], r["periodo"])
        if chave in vistos:
            r["utilizavel"] = False
            r["problemas_qualidade"].append(f"registro_duplicado:id_original={vistos[chave]}")
            logger.warning("Qualidade: id=%s duplicado de id=%s", r.get("id"), vistos[chave])
        else:
            vistos[chave] = r.get("id")

    validos = [r for r in tratados if r["utilizavel"]]
    invalidos = [r for r in tratados if not r["utilizavel"]]
    return {
        "registros": tratados,
        "validos": validos,
        "invalidos": invalidos,
        "falhas_processamento": falhas,
        "total": len(registros),
        "total_validos": len(validos),
        "total_invalidos": len(invalidos) + len(falhas),
    }


# --------------------------------------------------------------------------
# Saída segura para cálculos e para a IA
# --------------------------------------------------------------------------
def formatar_brl(valor: float) -> str:
    return "R$ " + f"{valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def agregar_por_metrica(validos: list[dict[str, Any]]) -> dict[tuple[str, str], float]:
    """Soma por (departamento, métrica): nunca mistura métricas diferentes."""
    totais: dict[tuple[str, str], float] = {}
    for r in validos:
        chave = (r["departamento"], r["metrica"])
        totais[chave] = totais.get(chave, 0.0) + r["valor_monetario"]
    return totais


def montar_contexto_ia(resultado: dict[str, Any]) -> str:
    """
    Texto seguro para enviar à IA: só registros validados, mais um resumo
    da quantidade de registros isolados (sem detalhes dos erros).
    """
    validos = resultado["validos"]
    if not validos:
        return ("Não há registros válidos na base. Informe ao usuário que os dados "
                "estão indisponíveis e NÃO estime valores.")

    linhas = [
        f"Indicadores validados ({resultado['total_validos']} de {resultado['total']} registros). "
        f"{resultado['total_invalidos']} registro(s) foram isolados por inconsistência "
        "e não devem ser estimados nem inferidos."
    ]
    for r in sorted(validos, key=lambda x: (x["periodo"], x["departamento"]))[:LIMITE_LINHAS_CONTEXTO_IA]:
        linha = (f"- {r['periodo']} | {r['departamento']} | {r['metrica']} | "
                 f"{formatar_brl(r['valor_monetario'])}")
        if r["variacao"] is not None:
            linha += f" | variação {r['variacao']:.1f}%"
        linhas.append(linha)
    if len(validos) > LIMITE_LINHAS_CONTEXTO_IA:
        linhas.append(f"(lista truncada em {LIMITE_LINHAS_CONTEXTO_IA} linhas)")
    return "\n".join(linhas)
